# FaBoPWM-PCA9685-Library

This is a library for FaBo PWM PCA9685.

## FaBo PWM PCA9685

FaBo PWM PCA9685

## PCA9685

PCA9685 is NXP Semiconductors's I2C PWM chip.

### PCA9685 Datasheet

[PCA9685 Datasheet](https://www.nxp.com/docs/en/data-sheet/PCA9685.pdf)

## Releases

- 1.0.0 Initial release.

## How to install.

[Installing Additional Arduino Libraries](https://www.arduino.cc/en/Guide/Libraries)
